"""
model_inference.py
Script pour charger et utiliser le meilleur modèle de détection de fraude en production

Auteur: 3 IDSD ID
Date: Novembre 2025
"""

import pandas as pd
import numpy as np
import pickle
import os
import warnings
from datetime import datetime

warnings.filterwarnings('ignore')


class FraudDetectionInference:
    """
    Classe pour faire des prédictions de fraude en production
    
    Cette classe charge:
    - Le meilleur modèle entraîné
    - Les processeurs de preprocessing (scaler, encodeurs)
    - Les métadonnées du modèle
    
    Usage:
    ------
    >>> detector = FraudDetectionInference()
    >>> detector.load_model()
    >>> prediction = detector.predict(transaction_data)
    """
    
    def __init__(self, processor_dir='processors'):
        """
        Initialise le système d'inférence
        
        Parameters:
        -----------
        processor_dir : str
            Chemin vers le dossier contenant les processeurs
        """
        self.processor_dir = processor_dir
        self.model = None
        self.scaler = None
        self.label_encoders = None
        self.feature_names = None
        self.metadata = None
        
        print(f"{'='*80}")
        print(f"🤖 FRAUD DETECTION INFERENCE SYSTEM")
        print(f"{'='*80}")
        print(f"📁 Processor directory: {processor_dir}")
    
    def load_model(self):
        """
        Charge le meilleur modèle et tous les processeurs nécessaires
        
        Returns:
        --------
        bool : True si chargement réussi, False sinon
        """
        print(f"\n{'='*80}")
        print("CHARGEMENT DU MODÈLE ET DES PROCESSEURS")
        print(f"{'='*80}\n")
        
        try:
            # Charger le modèle (essayer d'abord best_model_final.pkl, puis best_model.pkl)
            model_files = ['best_model_final.pkl', 'best_model.pkl']
            model_path = None
            
            for model_file in model_files:
                test_path = os.path.join(self.processor_dir, 'models', model_file)
                if os.path.exists(test_path):
                    model_path = test_path
                    break
            
            if model_path is None:
                raise FileNotFoundError(
                    f"Aucun modèle trouvé dans {os.path.join(self.processor_dir, 'models/')}\n"
                    f"Fichiers recherchés: {', '.join(model_files)}"
                )
            
            with open(model_path, 'rb') as f:
                self.model = pickle.load(f)
            print(f"✅ Modèle chargé: {model_path}")
            
            # Charger les métadonnées (essayer les deux noms)
            metadata_files = ['best_model_final_metadata.pkl', 'best_model_metadata.pkl']
            metadata_path = None
            
            for metadata_file in metadata_files:
                test_path = os.path.join(self.processor_dir, 'models', metadata_file)
                if os.path.exists(test_path):
                    metadata_path = test_path
                    break
            
            if metadata_path is None:
                print(f"⚠️  Métadonnées non trouvées (optionnel)")
                self.metadata = None
            else:
                with open(metadata_path, 'rb') as f:
                    self.metadata = pickle.load(f)
                print(f"✅ Métadonnées chargées: {metadata_path}")
            
            # Charger le scaler
            scaler_path = os.path.join(self.processor_dir, 'scaler.pkl')
            with open(scaler_path, 'rb') as f:
                self.scaler = pickle.load(f)
            print(f"✅ Scaler chargé: {scaler_path}")
            
            # Charger les label encoders
            encoders_path = os.path.join(self.processor_dir, 'label_encoders.pkl')
            with open(encoders_path, 'rb') as f:
                self.label_encoders = pickle.load(f)
            print(f"✅ Label encoders chargés: {encoders_path}")
            
            # Charger les noms des features
            features_path = os.path.join(self.processor_dir, 'feature_names.pkl')
            with open(features_path, 'rb') as f:
                self.feature_names = pickle.load(f)
            print(f"✅ Feature names chargés: {features_path}")
            
            # Afficher les informations du modèle
            print(f"\n{'─'*80}")
            print(f"📊 INFORMATIONS DU MODÈLE")
            print(f"{'─'*80}")
            
            if self.metadata is not None:
                print(f"  • Nom: {self.metadata['model_name']}")
                print(f"  • ROC-AUC: {self.metadata['metrics']['roc_auc']:.4f}")
                print(f"  • Precision: {self.metadata['metrics']['precision']:.4f}")
                print(f"  • Recall: {self.metadata['metrics']['recall']:.4f}")
                print(f"  • F1-Score: {self.metadata['metrics']['f1_score']:.4f}")
                print(f"  • Date d'entraînement: {self.metadata['timestamp']}")
                print(f"  • Nombre de features: {len(self.feature_names['all_features'])}")
            else:
                print(f"  • Modèle: {os.path.basename(model_path)}")
                print(f"  • Nombre de features: {len(self.feature_names['all_features'])}")
                print(f"  • Métadonnées: Non disponibles")
            
            print(f"\n✅ Tous les composants chargés avec succès!")
            return True
            
        except FileNotFoundError as e:
            print(f"❌ ERREUR: Fichier non trouvé - {e}")
            print(f"\n💡 Assurez-vous d'avoir exécuté:")
            print(f"   1. Le preprocessing (preprocessing_fraud_class.py)")
            print(f"   2. Le notebook de modélisation (fraud_detection_modeling.ipynb)")
            return False
        except Exception as e:
            print(f"❌ ERREUR lors du chargement: {e}")
            return False
    
    def predict(self, X, return_proba=False):
        """
        Fait des prédictions sur de nouvelles données
        
        Parameters:
        -----------
        X : array-like or DataFrame
            Données à prédire (déjà preprocessées)
        return_proba : bool
            Si True, retourne les probabilités au lieu des classes
        
        Returns:
        --------
        array : Prédictions (0 = Normal, 1 = Fraude)
                ou probabilités si return_proba=True
        """
        if self.model is None:
            raise ValueError("❌ Le modèle n'est pas chargé. Appelez load_model() d'abord.")
        
        if return_proba:
            return self.model.predict_proba(X)[:, 1]
        else:
            return self.model.predict(X)
    
    def predict_single(self, transaction_data, threshold=0.5):
        """
        Fait une prédiction sur une seule transaction
        
        Parameters:
        -----------
        transaction_data : dict or DataFrame
            Données de la transaction (une seule ligne)
        threshold : float
            Seuil de décision pour classifier comme fraude
        
        Returns:
        --------
        dict : Résultat de la prédiction avec probabilité et décision
        """
        if self.model is None:
            raise ValueError("❌ Le modèle n'est pas chargé. Appelez load_model() d'abord.")
        
        # Convertir en DataFrame si nécessaire
        if isinstance(transaction_data, dict):
            df = pd.DataFrame([transaction_data])
        else:
            df = transaction_data
        
        # Prédiction
        proba = self.model.predict_proba(df)[:, 1][0]
        is_fraud = int(proba >= threshold)
        
        result = {
            'is_fraud': is_fraud,
            'fraud_probability': proba,
            'confidence': proba if is_fraud else 1 - proba,
            'risk_level': self._get_risk_level(proba),
            'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        }
        
        return result
    
    def _get_risk_level(self, probability):
        """
        Détermine le niveau de risque basé sur la probabilité
        
        Parameters:
        -----------
        probability : float
            Probabilité de fraude
        
        Returns:
        --------
        str : Niveau de risque
        """
        if probability < 0.3:
            return "FAIBLE"
        elif probability < 0.6:
            return "MOYEN"
        elif probability < 0.8:
            return "ÉLEVÉ"
        else:
            return "TRÈS ÉLEVÉ"
    
    def predict_batch(self, transactions_df, threshold=0.5, return_details=False):
        """
        Fait des prédictions sur un batch de transactions
        
        Parameters:
        -----------
        transactions_df : DataFrame
            DataFrame contenant plusieurs transactions
        threshold : float
            Seuil de décision
        return_details : bool
            Si True, retourne un DataFrame avec tous les détails
        
        Returns:
        --------
        array or DataFrame : Prédictions ou DataFrame détaillé
        """
        if self.model is None:
            raise ValueError("❌ Le modèle n'est pas chargé. Appelez load_model() d'abord.")
        
        # Prédictions
        probas = self.model.predict_proba(transactions_df)[:, 1]
        predictions = (probas >= threshold).astype(int)
        
        if return_details:
            results_df = transactions_df.copy()
            results_df['fraud_probability'] = probas
            results_df['is_fraud_predicted'] = predictions
            results_df['risk_level'] = [self._get_risk_level(p) for p in probas]
            results_df['prediction_timestamp'] = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            return results_df
        else:
            return predictions
    
    def get_model_info(self):
        """
        Retourne les informations sur le modèle chargé
        
        Returns:
        --------
        dict : Informations du modèle
        """
        if self.model is None:
            return {"error": "Modèle non chargé"}
        
        if self.metadata is None:
            return {
                'model_name': 'Unknown',
                'metrics': {
                    'roc_auc': 'N/A',
                    'precision': 'N/A',
                    'recall': 'N/A',
                    'f1_score': 'N/A',
                    'accuracy': 'N/A'
                },
                'training_date': 'N/A',
                'n_features': len(self.feature_names['all_features']) if self.feature_names else 'N/A'
            }
        
        return {
            'model_name': self.metadata['model_name'],
            'metrics': self.metadata['metrics'],
            'training_date': self.metadata['timestamp'],
            'n_features': len(self.feature_names['all_features'])
        }
    
    def print_summary(self):
        """
        Affiche un résumé du système d'inférence
        """
        print(f"\n{'='*80}")
        print(f"📊 RÉSUMÉ DU SYSTÈME D'INFÉRENCE")
        print(f"{'='*80}")
        
        if self.model is None:
            print("⚠️  Aucun modèle chargé")
        else:
            info = self.get_model_info()
            
            if 'error' in info:
                print(f"⚠️  {info['error']}")
            else:
                print(f"\n🤖 Modèle: {info['model_name']}")
                if info['training_date'] != 'N/A':
                    print(f"📅 Date d'entraînement: {info['training_date']}")
                print(f"🎯 Nombre de features: {info['n_features']}")
                
                if info['metrics']['roc_auc'] != 'N/A':
                    print(f"\n📊 Performances:")
                    for metric, value in info['metrics'].items():
                        print(f"   • {metric.replace('_', ' ').title()}: {value:.4f}")
                else:
                    print(f"\n📊 Performances: Métadonnées non disponibles")


def example_usage():
    """
    Exemple d'utilisation du système d'inférence
    """
    print("\n" + "="*80)
    print("📖 EXEMPLE D'UTILISATION")
    print("="*80 + "\n")
    
    # Initialiser le système
    detector = FraudDetectionInference(processor_dir='processors')
    
    # Charger le modèle
    if detector.load_model():
        # Afficher le résumé
        detector.print_summary()
        
        print(f"\n{'─'*80}")
        print("💡 EXEMPLES DE PRÉDICTION")
        print(f"{'─'*80}\n")
        
        print("1️⃣  Prédiction sur données preprocessées:")
        print("   >>> predictions = detector.predict(X_test)")
        print("   >>> probabilities = detector.predict(X_test, return_proba=True)")
        
        print("\n2️⃣  Prédiction sur une transaction:")
        print("   >>> result = detector.predict_single(transaction_data)")
        print("   >>> print(result)")
        print("   >>> # {'is_fraud': 1, 'fraud_probability': 0.89, ...}")
        
        print("\n3️⃣  Prédiction sur un batch:")
        print("   >>> results_df = detector.predict_batch(")
        print("   ...     transactions_df,")
        print("   ...     threshold=0.5,")
        print("   ...     return_details=True")
        print("   ... )")
        
        print("\n4️⃣  Informations du modèle:")
        print("   >>> info = detector.get_model_info()")
        print("   >>> print(info['model_name'])")


if __name__ == "__main__":
    """
    Point d'entrée principal
    """
    print("""
    ╔════════════════════════════════════════════════════════════════════════╗
    ║                                                                        ║
    ║            SYSTÈME D'INFÉRENCE - DÉTECTION DE FRAUDE                  ║
    ║                                                                        ║
    ║                        Projet MLOps 2025                              ║
    ║                         3 IDSD ID                                     ║
    ║                                                                        ║
    ╚════════════════════════════════════════════════════════════════════════╝
    """)
    
    example_usage()
    
    print(f"\n{'='*80}")
    print("✅ Script terminé")
    print(f"{'='*80}\n")
